<?php

date_default_timezone_set($GLOBALS['config']['APP_TIMEZONE']);
